export default class Event {
    // implement your code here...
    constructor(events, types) {
        this.events = events;
        this.types = types;
    }
    
};

