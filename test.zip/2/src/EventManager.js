export default class EventManager{
    run() {

    }
};